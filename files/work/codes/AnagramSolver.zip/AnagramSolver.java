/*Jonathan Oh
 * CSE 143 AK with Maxwell Peterson
 * Homework 6
 *
 * This creates an Anagram solver that uses a dictionary and finds all the anagrams
 * of a given word or phrase matching the maximum possibilities that the user 
 * wants.*/

import java.util.*;

public class AnagramSolver {
   private List<String> dict;
   private Map<String, LetterInventory> map;
   
   /* pre: passes in the dictionary
    * post: Uses the dictionary and organizes them into a map*/
   public AnagramSolver(List<String> list) {
      dict = list;
      map = new HashMap<String, LetterInventory>();
      for(String word: dict) {
         map.put(word, new LetterInventory(word));
      }
   }
   
   /* pre: Max has to be greater than or equal to 0. Throws
    * IllegalArgumentException otherwise.
    *
    * post:This will print all the anagrams with the maximum possible number
    * of words and when the maximum number is 0, the anagrams will display.*/   
   public void print(String s, int max) {
      if(max < 0)
         throw new IllegalArgumentException();
      if(max == 0)
         max = s.length();
      LetterInventory inventory = new LetterInventory(s);
      Stack<String> s1 = new Stack<String>();
      List<String> outcomes = new ArrayList<String>();
      for(String word: dict)
         if (inventory.subtract(map.get(word)) != null)
            outcomes.add(word);
      print(inventory, max, s1, outcomes);
   }
   
   /* post: This will keep a track of the words that fit the anagrams and will pass
    * through the rest of the words if it does not match. This will go until
    * all the anagrams are found*/
   private void print(LetterInventory inventory, int max, 
		   Stack<String> s, List<String> outcomes) {
      if (inventory.isEmpty()) {
         System.out.println(s);
      } else {
         for (String word : dict) {
 			if(s.size() < max) {
               LetterInventory temp = inventory.subtract(map.get(word));
               s.push(word);
               if (temp != null)
                  print(temp, max, s, outcomes);
               s.pop();
            }
         }
      }
   }
}