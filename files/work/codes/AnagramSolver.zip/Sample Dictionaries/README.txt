Instructions:

When running the program, drag any of the text files in this folder
to the parent directory to get different results