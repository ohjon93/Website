This is the source code for Anagrams. To run the program, simply compile
AnagramMain.java  and AnagramSolver.java with any type of java program,
then continue running them in the command line.

Enjoy